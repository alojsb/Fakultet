﻿namespace DLWMS.Data
{
    public class Spol
    {
        public int Id { get; set; }
        public string Naziv { get; set; }
        public bool Aktivan { get; set; }
    }
}