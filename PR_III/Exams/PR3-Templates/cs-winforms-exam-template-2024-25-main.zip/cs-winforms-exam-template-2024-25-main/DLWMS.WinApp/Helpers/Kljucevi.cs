﻿namespace DLWMS.WinApp.Helpers
{
    public class Kljucevi
    {
        public const string NotActive = "NotActive";
        public const string UsernameOrPasswordNotValid = "UsernameOrPasswordNotValid";
        public const string Warning = "Warning";
        public const string Domain = "Domain";
        public const string RequiredField = "RequiredField";
        public const string UserAddSuccess = "UserAddSuccess";
        public const string Information = "Information";

    }
}
